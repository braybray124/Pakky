#include "../include/mixer.h"

int db_init() {
    // TODO: Ensure /var/mixer/db exists, create if missing
    return 0;
}
