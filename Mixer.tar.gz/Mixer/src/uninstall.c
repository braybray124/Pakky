#include "../include/mixer.h"

int mixer_uninstall(const char *pkg) {
    // TODO: Remove package files, update track.json
    return 0;
}
