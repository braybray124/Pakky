#include "../include/mixer.h"

int mixer_install(const char *pkg) {
    // TODO: Read .toml, resolve deps, fetch & install package, update track.json
    return 0;
}
