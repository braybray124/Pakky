#ifndef MIXER_H
#define MIXER_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void mixer_progress_bar(int current, int total);
// ...existing code...
#endif // MIXER_H
