#include "../include/mixer.h"

int mixer_update() {
    // TODO: Update all installed packages
    return 0;
}
