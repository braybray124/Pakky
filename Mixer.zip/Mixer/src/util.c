#include "../include/mixer.h"

void mixer_progress_bar(int current, int total) {
	int width = 40; // width of the bar
	float percent = (float)current / total;
	int pos = (int)(width * percent);
	printf("\r[");
	for (int i = 0; i < width; ++i) {
		if (i < pos) printf("-");
		else if (i == pos) printf(">\");
		else printf(" ");
	}
	printf("] %3d%%", (int)(percent * 100));
	fflush(stdout);
	if (current == total) printf("\n");
}
// Utility functions for mixer
