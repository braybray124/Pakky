#include "../include/mixer.h"

int mixer_sync() {
    // TODO: Implement sync logic (fetch .toml metadata, update db)
    return 0;
}
